/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package pruebainterfaz;

/**
 *
 * @author jmrivera
 */
public interface ICuentaCorriente {
    boolean ingresarEnCuenta(double dinero);
    boolean retirarEfectivo(double dinero);
    void mostrarSaldo();
    void mostrarDatos();
    boolean transferenciaBancaria(double dinero, ICuentaCorriente objetoCuenta);
}
