/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pruebainterfaz;

/**
 *
 * @author jmrivera
 */
public class PruebaInterfaz {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Cuenta c1, c2;
        c1 = new CuentaCorriente(100, "Manuel", "Ruiz de Lopera", 1600);
        c2 = new CuentaAhorro(200, "José María", "del Nido Benavente", 5000);
        System.out.println("Datos:");
        c1.mostrarDatos();
        c2.mostrarDatos();
        
        System.out.println("Retirando 575€");
        if (c1.retirarEfectivo(575)){
            c1.mostrarSaldo();
        }else{
            System.out.println("Error sacando dinero de la cuenta 1");
        }
        if (c2.retirarEfectivo(150)){
            c2.mostrarSaldo();
        }else{
            System.out.println("Error sacando dinero de la cuenta 2");
        }
        System.out.println("Transferencia de Lopera a DelNido de 263");
        if(c1.transferenciaBancaria(263, c2)){
            c1.mostrarSaldo();
            c2.mostrarSaldo();
        }else{
            System.out.println("Error transferencia.");
        }
        System.out.println("Transferencia DelNido a Lopera de 627");
        if(c2.transferenciaBancaria(200, c1)){
            c1.mostrarSaldo();
            c2.mostrarSaldo();
        }else{
            System.out.println("Error transferencia.");
        }
    }
    
}
