Tenemos una interfaz ICuentaCorriente. La interfaz contiene los métodos:

ingresarEnCuenta que recibe un parámetro dinero tipo double. 
retirarEfectivo con un parámetro dinero tipo double. 
mostrarSaldo que no recibe parámetros.
mostrarDatos que no recibe parámetros.
transferenciaBancaria que recibe un parámetro double, dinero, y un objeto tipo InterfazCuenta llamado objetoCuenta.


La clase Cuenta, de la cual no se pueden crear objetos e implementa dicha interfaz contará con los atributos privados:

numCuenta, de tipo entero.
nombre, String.
apellidos, String.
saldo, de tipo double. 

Tiene el constructor con parámetros además de los getters y setters para todos los atributos. 
Esta clase implementa los métodos de la interfaz. 
La transferencia bancaria lo que hace es sacar dinero del objeto que llama al método, para ingresarlo en el objeto cuenta que se pasa como parámetro.



Después tenemos dos clases que heredan de la clase anterior: CuentaCorriente y CuentaAhorro:

En CuentaCorriente el máximo a retirar es de 600 euros mientras que en CuentaAhorro es de 200 euros.
Al realizar una transferencia bancaria, en la CuentaCorriente la comisión es del 1% de la transferencia mientras que en la CuentaAhorro es de 0.5%.



Realizaremos un programa principal 

donde tengamos un objeto CuentaCorriente con 1.600 euros que pertenece a Manuel Ruiz de Lopera y un objeto CuentaAhorro 
que tiene un saldo de 5.000 euros que pertenece a José María del Nido Benavente.
 
En el programa principal vamos a usar 
una retiradaEfectivo de ambas cuentas de 575 euros, 
también vamos a realizar una transferencia desde la cuenta de Manuel Ruiz de Lopera a la cuenta de José María del Nido Benavente de 263 euros, 
y luego una transferencia desde la cuenta de José María del Nido Benavente a la cuenta de Manuel Ruiz de Lopera de 627 euros.


En este programa también mostraremos por pantalla el saldo de cada cuenta después de cada operación.