package interfaceinmobiliaria;

/**
 *
 * @author 
 */
public interface IComparable {
    boolean menorQue(IComparable otroObjeto, int opcion);
    boolean mayorQue(IComparable otroObjeto, int opcion);
    boolean igualQue(IComparable otroObjeto, int opcion);
}