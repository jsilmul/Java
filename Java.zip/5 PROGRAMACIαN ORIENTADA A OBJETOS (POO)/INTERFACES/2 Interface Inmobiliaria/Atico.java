package interfaceinmobiliaria;
/**
 *
 * @author 
 */

public class Atico extends Vivienda {
    
    // atributo
    double terraza;
    
    // metodos
    
    //constructor con parametros
    public Atico(double terraza, int numHabitaciones, int numBaños, int plazasGaraje, int planta, double superficie, String direccion, double precio) {
        super(numHabitaciones, numBaños, plazasGaraje, planta, superficie, direccion, precio);
        this.terraza = terraza;
    }
    
    //getters y setters
    public double getTerraza() {
        return terraza;
    }

    public void setTerraza(double terraza) {
        this.terraza = terraza;
    }

    public double getSuperficie() {
        return superficie;
    }

    public void setSuperficie(double superficie) {
        this.superficie = superficie;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    
    //metodo precioAlquiler
    public double precioAlquiler(){
        return super.superficie + this.terraza*20;
    }
    
    
    // metodo comision
    public double comision() {      
        return super.superficie + this.terraza*10;
    }
       
    // metodo verDatos
    public void verDatos(){
    System.out.println("Atico: ");
    super.verDatos();
    System.out.println("Terraza en mts2"+terraza);
    System.out.println("alquiler: "+precioAlquiler());
    System.out.println("comisión: "+comision());  
    }   
}
