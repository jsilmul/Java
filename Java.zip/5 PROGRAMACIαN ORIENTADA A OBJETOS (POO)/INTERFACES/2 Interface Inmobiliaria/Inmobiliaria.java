package interfaceinmobiliaria;

import java.util.Scanner;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
/**
 *
 * @author 
 */

public class Inmobiliaria implements IOrdenaArray {
    // atributos
    private String nombre;
    private String cif;
    private String direccion;
    private String propietario;
    //inmuebles, vector de objetos de la clase Inmueble
    private Inmueble[] inmuebles;
    //cuenta, objeto de la clase Cuenta
    private Cuenta cuenta; 
    private int numeroInmuebles = 5; //hay 5 inmuebles
    
    // metodos

    // constructor con parametro
    public Inmobiliaria(String nombre, String cif, String direccion, String propietario, double saldo) {
        this.nombre = nombre;
        this.cif = cif;
        this.direccion = direccion;
        this.propietario = propietario;
        //vector de tamaño 100
        inmuebles = new Inmueble[100];
        //inicializar a 0 el numero de inmuebles
        this.numeroInmuebles = 0;
        //construir el objeto cuenta con los datos: nombre, cif, saldo y tipo de interés 10
        cuenta = new Cuenta (nombre, cif, 10, saldo);   
    }
    
    
    // getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getPropietario() {
        return propietario;
    }

    public void setPropietario(String propietario) {
        this.propietario = propietario;
    }

    public Inmueble[] getInmuebles() {
        return inmuebles;
    }

    public void setInmuebles(Inmueble[] inmuebles) {
        this.inmuebles = inmuebles;
    }

    public Cuenta getCuenta() {
        return cuenta;
    }

    public void setCuenta(Cuenta cuenta) {
        this.cuenta = cuenta;
    }

    public int getNumeroInmuebles() {
        return numeroInmuebles;
    }

    public void setNumeroInmuebles(int numeroInmuebles) {
        this.numeroInmuebles = numeroInmuebles;
    }
    
    
    // metodo altaInmueble, recibira un objeto de la clase Inmueble y lo insertara en 
    // el vector, si puede
    public boolean altaInmueble (Inmueble i){
        boolean estado = false;
        if(numeroInmuebles < inmuebles.length && i !=null){
            inmuebles[numeroInmuebles] = i;
            numeroInmuebles++;
            estado = true;
        }
        return estado;
    }
    
    // metodo devolverInmueble, devolvera un objeto de tipo Inmueble o null, y 
    // recibira como parametro la posicion del vector
    public Inmueble devolverInmueble (int posicion){
        Inmueble i = null;
        
        if (posicion >= 0 && posicion < numeroInmuebles){
            i = inmuebles[posicion];
        }
        return i;
    }
        
    
    // metodo bajaInmueble
    public boolean bajaInmueble(int posicion){
      if(devolverInmueble(posicion) != null){
         numeroInmuebles--;
         inmuebles[posicion] = inmuebles[numeroInmuebles];
        i nmuebles[numeroInmuebles] = null;
       return true;
      }
     return false;
    }

    // metodo alquilar, reibira la posicion del vector del inmueble a alquilar
    public boolean alquilar(int posicion){
        Inmueble i = devolverInmueble(posicion);
        boolean estado = false;
        double saldo = 0;
        
        if (posicion > 0 && i != null){
            saldo += posicion;
            cuenta.ingreso(i.comision());
            estado = true;
        }
       return estado;
    }
    
    
    
    
    // metodo pedirDatos, pedira por teclado todos los datos de un nuevo inmueble 
    // devolviendo un objeto  de la clase Inmueble o null
    public static Inmueble pedirDatos(){
        Inmueble i = null;
        Scanner teclado = new Scanner(System.in);
        String direccion;
        double superficie, precio;
        int numHabitaciones, numBaños, plazasGaraje, planta; 
        char tipodeInmueble;
        
        System.out.println("\nTipo de inmueble (local/vivienda):");
        try{
            tipodeInmueble = teclado.nextLine().charAt(0);
        }catch(Exception error){
            tipodeInmueble = 'x';      
        }
        if (tipodeInmueble == 'l' || tipodeInmueble == 'v'){
            System.out.println("Superficie: ");
            superficie = Double.parseDouble(teclado.nextLine());
            System.out.println("Direccion: ");
            direccion = teclado.nextLine();
            System.out.println("Precio: ");
            precio = Double.parseDouble(teclado.nextLine());
            switch(tipodeInmueble){
                    case 'l':
                       i = new Local(superficie, direccion, precio);
                       break;
                    case 'v':
                        System.out.println("Numero de Habitaciones: ");
                        numHabitaciones = Integer.parseInt(teclado.nextLine());
                        System.out.println("Numero de Baños: ");
                        numBaños = Integer.parseInt(teclado.nextLine());
                        System.out.println("Numero de Plazas de Garaje: ");
                        plazasGaraje = Integer.parseInt(teclado.nextLine());
                        System.out.println("Numero de Planta: ");
                        planta = Integer.parseInt(teclado.nextLine());
                        i = new Vivienda(numHabitaciones, numBaños, plazasGaraje, planta, superficie, direccion, precio);
                        break;
            }
        }
        return i;     
    }
       
    // metodo verDatos, mostrara los datos de tipo String de la inmobiliaria, el
    // numero de inmuebles y el saldo de la cuenta
    public void verDatos(){
        System.out.println("Nombre: "+nombre);
        System.out.println("Cif: "+cif);
        System.out.println("Direccion: "+direccion);
        System.out.println("Propietario: "+propietario);
        System.out.println("Nº de Inmuebles: "+numeroInmuebles);      
        System.out.println("Saldo: "+cuenta.getSaldo());
    }
       
    // metodo verDatosInmuebles, mostrara todos los datos de todos los inmuebles 
    // de la inmobiliaria     
    public void verDatosInmuebles(){
       System.out.println("Datos de todos lo inmuebles: \n"); 
       for(int i = 0; i < numeroInmuebles; i++){
            inmuebles[i].verDatos();
            System.out.println(""); 
       }
    }
	
	
	//implementacion del metodo de la interface (IOrdenaArray)
	@Override
    public void ordenaPor(int opcion) {
        
        Inmueble aux;
        
        for(int i = 0; i < numeroInmuebles - 1; i++) {
            for (int j = numeroInmuebles - 1; j > i ; j--) {
                
                if (inmuebles[j].menorQue(inmuebles[j-1], opcion)) {
                    aux = inmuebles[j];
                    inmuebles[j] = inmuebles[j-1];
                    inmuebles[j-1] = aux;
                }
            }
        }
    }
	
	
	    public void leerFicheros (){
        
        double superficie = 0.0;
        String direccion = "";
        double precio = 0.0;
        int contador = 1;
       
        try{
            FileReader fichero = new FileReader("Locales.txt");
            BufferedReader bf = new BufferedReader(fichero);
			
            String linea = bf.readLine();
			
            while(linea != null) {
                System.out.println(linea);
                //convertir cadena a double

                switch(contador){
                    case 1:
                        superficie = Double.parseDouble(linea);
                        contador ++;
                        break;
                    case 2:
                        direccion = linea;
                        contador++;
                        break;
                    case 3:
                        precio = Double.parseDouble(linea);

                        Local bardecopas = new Local(superficie, direccion, precio);
                        altaInmueble(bardecopas);
                        contador = 1;
                        break;
                    }
                    linea = bf.readLine();
            }		
            bf.close();
		
        }catch(FileNotFoundException e) {
                System.out.println("No se encuentra el fichero Locales.txt");
        }catch(IOException e) {
                System.out.println("No se puede leer el fichero Locales.txt");
        }
    }
	
	
}
