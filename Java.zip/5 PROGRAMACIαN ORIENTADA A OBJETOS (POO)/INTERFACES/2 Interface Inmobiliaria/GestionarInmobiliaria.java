package interfaceinmobiliaria;

import java.util.Scanner;
/**
 *
 * @author
 * 
 */

public class GestionarInmobiliaria {
/**
 * 
 * @param args the command line arguments
 * 
 */
   
  // metodo main  
  public static void main(String[] args) {
    // El metodo main tendra un objeto de tipo Inmobiliaria que se construirá con 
    // unos datos concretos, siendo el nombre del propietario del alumno que hace
    // el examen 
    String nombre = "Jeronimo Silva Mulero"; 
    Scanner teclado = new Scanner(System.in);
    Inmobiliaria miInmobiliaria = new Inmobiliaria("Velázquez", "41-123456", "Feria 100", nombre, 1000.0);
    Inmueble miInmueble;
	
	miInmobiliaria.leerFicheros();
	
    char modificar;
    int opcion, posicion;

    do{
      opcion = menu();
      switch (opcion) {
        // ver o modificar los datos de la inmobiliaria  
        case 1:
            System.out.println("\nDatos de la Inmobiliaria: ");
            miInmobiliaria.verDatos();
            System.out.println("¿Quieres modificar los Datos de la Inmobiliaria (s/n)?:");
            try{
                modificar = teclado.nextLine().charAt(0);
            }catch(Exception e){
                modificar = 'n';
            }
            if(modificar == 's'){
                System.out.println("Nuevo nombre de de la Inmobiliria: ");
                miInmobiliaria.setNombre(teclado.nextLine());
                System.out.println("Nuevo cif de la Inmobiliria: ");
                miInmobiliaria.setCif(teclado.nextLine());
                System.out.println("Nueva direccion de la Inmobiliria: ");
                miInmobiliaria.setDireccion(teclado.nextLine());
                System.out.println("Nuevo propietario de la Inmobiliria:");
                miInmobiliaria.setPropietario(teclado.nextLine());
            }
          break;
        // dar de alta a un inmueble  
        case 2:
            miInmueble = pedirDatos();
            if (miInmobiliaria.altaInmueble(miInmueble)){
                System.out.println("Inmueble dado de alta.");
            }else{
                System.out.println("Error en el alta del inmueble.");
            }
           break;
        // dar de baja a un inmueble   
        case 3:
            System.out.println("Número del Inmueble:");
            try{
                  posicion = Integer.parseInt(teclado.nextLine());
                }catch(NumberFormatException e){
                  posicion = -1;
                }
            miInmueble = miInmobiliaria.devolverInmueble(posicion);
            if (miInmueble != null){
                miInmueble.verDatos();
            }
          break;
        // alquilar un inmueble  
        case 4:
            System.out.println("Alquilar un inmueble:");
            for(int i = 0; i < miInmobiliaria.getNumeroInmuebles(); i++){
                if(!miInmobiliaria.alquilar(i)){
            System.out.println("Error al alquilar el inmueble: "+miInmobiliaria.devolverInmueble(i));
                }else{
                    System.out.println("Error al alquilar el inmueble: "+miInmobiliaria.devolverInmueble(i));
                }
            }
          break;
        // ver los datos de un inmueble
        case 5:
           miInmobiliaria.verDatos();
          break;
        // ver los datos de todos los inmuebles
        case 6:
            miInmobiliaria.verDatosInmuebles();
          break;
		// ordenar los inmuebles por Array
        case 7:
            int tipoOrdenacion = Entrada.leerEntero("1. - Superficie \n 2. - Precio \n 3. - Alquiler");
            miInmobiliaria.ordenaPor(tipoOrdenacion);
          break;
        default:
      }
      esperar();
    }while(opcion != 0);
  }

  // este es el menu con sus opciones
  public static int menu(){
    Scanner teclado = new Scanner(System.in);
    int op;
    System.out.println("Menu");
    System.out.println("");
    System.out.println("1.- Ver/modificar los datos de la inmobiliaria.");
    System.out.println("2.- Dar de alta un inmueble.");
    System.out.println("3.- Dar de baja un inmueble.");
    System.out.println("4.- Alquilar un inmueble.");
    System.out.println("5.- Ver los datos de un inmueble.");
    System.out.println("6.- Ver los datos de todos los inmuebles.");
	System.out.println("7.- Ordenar inmuebles.");
    System.out.println("0.- Salir.");
    System.out.print("\n¿Opción?: ");
    try{
        op = Integer.parseInt(teclado.nextLine());
    }
        catch(NumberFormatException e){
        op = 100;
    }
    return op;
  }
  
  
  // metodo pedirDatos para solucionar el caso 2 del menu, dar de alta a un inmueble
  public static Inmueble pedirDatos(){
        Inmueble i = null;
        Scanner teclado = new Scanner(System.in);
        String direccion;
        double superficie, precio;
        int numHabitaciones, numBaños, plazasGaraje, planta; 
        char tipodeInmueble;
        
        System.out.println("\nTipo de inmueble (local/vivienda):");
        try{
            tipodeInmueble = teclado.nextLine().charAt(0);
        }catch(Exception error){
            tipodeInmueble = 'x';      
        }
        if (tipodeInmueble == 'l' || tipodeInmueble == 'v'){
            System.out.println("Superficie: ");
            superficie = Double.parseDouble(teclado.nextLine());
            System.out.println("Direccion: ");
            direccion = teclado.nextLine();
            System.out.println("Precio: ");
            precio = Double.parseDouble(teclado.nextLine());
            switch(tipodeInmueble){
                    case 'l':
                       i = new Local(superficie, direccion, precio);
                       break;
                    case 'v':
                        System.out.println("Numero de Habitaciones: ");
                        numHabitaciones = Integer.parseInt(teclado.nextLine());
                        System.out.println("Numero de Baños: ");
                        numBaños = Integer.parseInt(teclado.nextLine());
                        System.out.println("Numero de Plazas de Garaje: ");
                        plazasGaraje = Integer.parseInt(teclado.nextLine());
                        System.out.println("Numero de Planta: ");
                        planta = Integer.parseInt(teclado.nextLine());
                        i = new Vivienda(numHabitaciones, numBaños, plazasGaraje, planta, superficie, direccion, precio);
                        break;
            }
        }
        return i;     
    }
  
  // metodo de espera
    public static void esperar(){
      Scanner teclado = new Scanner(System.in);
      System.out.println("Pulse intro para continuar...");
      teclado.nextLine();
    }
  
}