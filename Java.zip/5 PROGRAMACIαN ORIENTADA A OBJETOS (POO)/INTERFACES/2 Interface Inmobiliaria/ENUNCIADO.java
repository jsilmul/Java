Partiendo del ejercicio del examen, vamos a implementar en la clase Inmueble, la primera interfaz, y en la clase inmobiliaria, la segunda:

1 Interface IComparable, que tendrá los siguientes métodos:
menorQue: que tendrá un parámetro llamado otroObjeto del tipo de la interfaz, y un parámetro llamado opcion, de tipo entero. 
Devolverá true cuando el objeto que llama al método es menos que el pasado por parámetro y false, en otro caso. 

El parámetro opcion indicará el criterio de comparación.
mayorQue: igual que el anterior.
igualQue: igual que el anterior.

2 Interface IOrdenaArray, que tendrá el siguiente método:
ordenaPor: que no devuelve nada y tendrá un único parámetro llamado opcion, de tipo entero, que ordenará el vector en función del criterio 
indicado por el parámetro.

Se añadirá al menú de la clase GestionarInmobiliaria la opción ordenar, que pedirá el criterio de ordenación:

1 Superficie del inmueble.
2 Precio del inmueble.
3 Precio de alquiler del inmueble.