package interfaceinmobiliaria;
/**
 *
 * @author 
 */

public class Vivienda extends Inmueble{

    // atributos
    private int numHabitaciones;
    private int numBaños;
    private int plazasGaraje;
    private int planta;
    private boolean ascensor;
    
    // metodos
    
    // constructor con parametros
    public Vivienda(int numHabitaciones, int numBaños, int plazasGaraje, int planta, double superficie, String direccion, double precio) {
        super(superficie, direccion, precio);
        this.numHabitaciones = numHabitaciones;
        this.numBaños = numBaños;
        this.plazasGaraje = plazasGaraje;
        this.planta = planta;
    }
    
    // setters y getters
    public int getNumHabitaciones() {
        return numHabitaciones;
    }

    public void setNumHabitaciones(int numHabitaciones) {
        this.numHabitaciones = numHabitaciones;
    }

    public int getNumBaños() {
        return numBaños;
    }

    public void setNumBaños(int numBaños) {
        this.numBaños = numBaños;
    }

    public int getPlazasGaraje() {
        return plazasGaraje;
    }

    public void setPlazasGaraje(int plazasGaraje) {
        this.plazasGaraje = plazasGaraje;
    }

    public int getPlanta() {
        return planta;
    }

    public void setPlanta(int planta) {
        this.planta = planta;
    }

    public boolean isAscensor() {
        return ascensor;
    }

    public void setAscensor(boolean ascensor) {
        this.ascensor = ascensor;
    }
    
    // metodo precioAlquiler, sera la suma de superficie por 10, numHabitaciones
    // por 50, numBaños por 50, si tiene acensor se le suma 50, si no lo tiene se
    // le resta el numero de plantas multiplicado
    public double precioAlquiler() {
        
        return this.superficie*10 + this.numHabitaciones * 50 + this.numBaños *10;
    }
    
    
    // metodo comision, el triple del precio del alquiler mas 1,5 del precio de 
    // la vivienda
    public double comision() {
        
        return precioAlquiler()*3 + this.precio;
    }
    
    
    // metodo verDatos
    public void verDatos(){
    System.out.println("Vivienda: ");
    super.verDatos();
    System.out.println("superficie "+numHabitaciones);
    System.out.println("superficie "+numBaños);
    System.out.println("superficie "+plazasGaraje);
    System.out.println("superficie "+planta);
    System.out.println("direccion "+ascensor);
    System.out.println("alquiler: "+precioAlquiler());
    System.out.println("comisión: "+comision());
    }  
}
