package interfaceinmobiliaria;
/**
 *
 * @author 
 */

public class Local extends Inmueble {

    // atributos, los de la clase padre, clase Inmueble
    private double superficie;
    private String direccion;
    private double precio;
    
    // metodos
    
    //constructor con parametros
    public Local(double superficie, String direccion, double precio) {
        super(superficie, direccion, precio);
        this.superficie = superficie;
        this.direccion = direccion;
        this.precio = precio;
    }
    
    // getters y setters
    public double getSuperficie() {
        return superficie;
    }

    public void setSuperficie(double superficie) {
        this.superficie = superficie;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    
    // metodo precioAlquiler
    public double precioAlquiler(){
    
        //return superficie*20;
        super.setSuperficie(super.getSuperficie()*20);
        return superficie;
    }
    
    
    // metodo comision, el doble del precio del Alquiler
    public double comision(){
        this.precioAlquiler();
        return precioAlquiler()*2;
    }

    
    // metodo verDatos
    public void verDatos(){
    System.out.println("Local: ");
    super.verDatos();
    System.out.println("alquiler: "+precioAlquiler());
    System.out.println("comisión: "+comision());
    }
    
}
