package interfaceinmobiliaria;

/**
 *
 * @author 
 */
public interface IOrdenaArray {
    void ordenaPor(int opcion);
}