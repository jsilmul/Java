package interfaceinmobiliaria;
/**
 *
 * @author 
 */

public abstract class Inmueble implements IComparable {
   double superficie;
   String direccion;
   double precio;

  public Inmueble(double superficie, String direccion, double precio) {
    this.superficie = superficie;
    this.direccion = direccion;
    this.precio = precio;
  }
  
  
  public double getSuperficie() {
    return superficie;
  }

  public void setSuperficie(double superficie) {
    this.superficie = superficie;
  }

  public String getDireccion() {
    return direccion;
  }

  public void setDireccion(String direccion) {
    this.direccion = direccion;
  }

  public double getPrecio() {
    return precio;
  }

  public void setPrecio(double precio) {
    this.precio = precio;
  }

  public void verDatos() {
    System.out.println("superficie "+superficie+" mts2");
    System.out.println("direccion "+direccion);
    System.out.println("precio "+precio+" euros");
    System.out.println("alquiler: "+precioAlquiler());
    System.out.println("comisión: "+comision());
  }
  
  public abstract double precioAlquiler();
  public abstract double comision();
  
  
  
  
  //implementacion de los metodos de la interface(IComparable)
        @Override
    public boolean menorQue(IComparable otroObjeto, int opcion) {
        Inmueble aux;
        aux = (Inmueble) otroObjeto;
        boolean estado = false;
        switch (opcion) {
            case 1:
                estado = this.getSuperficie() < aux.getSuperficie();
                break;
                
            case 2:
                estado = this.getPrecio() < aux.getPrecio();
                break;
                
            case 3:
                estado = this.precioAlquiler() < aux.precioAlquiler();
                break;    
        }
        return estado;
    }

    
    @Override
    public boolean mayorQue(IComparable otroObjeto, int opcion) {
        Inmueble aux;
        aux = (Inmueble) otroObjeto;
        boolean estado = false;
        switch (opcion) {
            case 1:
                estado = this.getSuperficie() > aux.getSuperficie();
                break;
                
            case 2:
                estado = this.getPrecio() > aux.getPrecio();
                break;
                
            case 3:
                estado = this.precioAlquiler() > aux.precioAlquiler();
                break;    
        }
        return estado;
    }

    
    @Override
    public boolean igualQue(IComparable otroObjeto, int opcion) {
        Inmueble aux;
        aux = (Inmueble) otroObjeto;
        boolean estado = false;
        switch (opcion) {
            case 1:
                estado = this.getSuperficie() == aux.getSuperficie();
                break;
                
            case 2:
                estado = this.getPrecio() == aux.getPrecio();
                break;
                
            case 3:
                estado = this.precioAlquiler() == aux.precioAlquiler();
                break;    
        }
        return estado;
    }

    
}