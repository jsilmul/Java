Incluir un menú en el main con las siguientes opciones:

1 Ingresar importe en la cuenta.
2 Retirar importe de la cuenta.
3 Transferir importe desde cuenta.
4 Ver datos de las cuentas.
En cada caso, pedirá el importe y la cuenta sobre la que se actua, considerando las dos ya creadas.