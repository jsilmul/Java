/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pruebainterfaz;

import java.util.Scanner;
/**
 *
 * @author Alumno_T
 */
public class PruebaInterfaz {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Cuenta c1, c2;
        c1 = new CuentaCorriente(100, "Manuel", "Ruiz de Lopera", 1600);
        c2 = new CuentaAhorro(200, "José María", "del Nido Benavente", 5000);
        System.out.println("Datos:");
        c1.mostrarDatos();
        c2.mostrarDatos();
        
        int opcion;
        double dinero;
        int importe;        
        
        
        System.out.println("Retirando 575€");
        if (c1.retirarEfectivo(575)){
            c1.mostrarSaldo();
        }else{
            System.out.println("Error sacando dinero de la cuenta 1");
        }
        if (c2.retirarEfectivo(150)){
            c2.mostrarSaldo();
        }else{
            System.out.println("Error sacando dinero de la cuenta 2");
        }
        System.out.println("Transferencia de Lopera a DelNido de 263");
        if(c1.transferenciaBancaria(263, c2)){
            c1.mostrarSaldo();
            c2.mostrarSaldo();
        }else{
            System.out.println("Error transferencia.");
        }
        System.out.println("Transferencia DelNido a Lopera de 627");
        if(c2.transferenciaBancaria(200, c1)){
            c1.mostrarSaldo();
            c2.mostrarSaldo();
        }else{
            System.out.println("Error transferencia.");
        }
        
        
        
    
    do{
      opcion = menu();
      switch (opcion){
            
            case 1: 
            importe = Entrada.leerEntero("¿A qué cuenta quieres ingresar el dinero, en la cuenta 1, "+c1.getNombre()+ " o en la cuenta 2," + c2.getNombre()+"?");
            dinero = Entrada.leerDouble("¿Cuanto dinero quieres ingresar?");
            if(importe == 1){
                c1.ingresarEnCuenta(dinero);
                System.out.println("Ingreso realizado");
                c1.mostrarSaldo();
            }else{
                if (importe == 2){
                c2.retirarEfectivo(dinero);
            }else{
                System.out.println("Ingreso no realizado");   
              }
            }
            break;
            
            
            case 2:
            importe = Entrada.leerEntero("¿A qué cuenta quieres retirar el dinero, a la cuenta 1, "+c1.getNombre()+ " o a la cuenta 2, " + c2.getNombre()+"?");
            dinero = Entrada.leerDouble("¿Cuanto dinero quieres retirar?");         
            if(importe == 1){
                c1.retirarEfectivo(dinero);
                System.out.println("Retirada de efectivo realizado");
                c1.mostrarSaldo();
            }else{
                if (importe == 2){
                c2.retirarEfectivo(dinero);
            }else{
                System.out.println("Retirada de efectivo no realizada");
      
                }
            }
            break;
            
            case 3:
                importe = Entrada.leerEntero("¿A qué cuenta quieres transferir el dinero, a la cuenta 1, "+c1.getNombre()+ " o a la cuenta 2, " + c2.getNombre()+"?");
                dinero = Entrada.leerDouble("¿Qué cantidad quieres transferir?");
            if(importe == 1){
                c1.transferenciaBancaria(dinero, c1);
                System.out.println("Transferencia realizada correctamente");
                c1.mostrarSaldo();
                c2.mostrarSaldo();
            }else{
                if(importe ==2){
                c2.transferenciaBancaria(dinero, c2);
                System.out.println("Transferencia realizada correctamente");
                c2.mostrarSaldo();
                c1.mostrarSaldo();
                }
            }
            break;
      
            case 4:
                importe = Entrada.leerEntero("¿De qué cuenta quieres ver los datos, de la cuenta 1, " +c1.getNombre()+ " o de la cuenta 2, " + c2.getNombre()+"?");
            if(importe ==1){
                System.out.println("Los datos de esta cuenta son los que siguen: ");
                c1.mostrarDatos();
            }else{
                if(importe ==2){
                System.out.println("Los datos de esta cuenta son los que siguen: ");
                c2.mostrarDatos();
                } 
            }
            break;
            default:
        }
        Entrada.leerCadena("Pulsa Intro para seguir......:");
    }while(opcion != 0);
    }
    
    
  public static int menu(){
    Scanner teclado = new Scanner(System.in);
    int opcion;
    System.out.println("Menu de Opciones");
    System.out.println("");
    System.out.println("1.- Ingresar importe en la cuenta.");
    System.out.println("2.- Retirar importe de la cuenta.");
    System.out.println("3.- Transferir importe desde cuenta.");
    System.out.println("4.- Ver datos de las cuentas.");
    System.out.println("0.- Salir.");
    System.out.print("\n¿Opción?: ");
    try{
        opcion = Integer.parseInt(teclado.nextLine());
        }
      catch(NumberFormatException e){
      opcion = 100;
    }
    return opcion;
  }
    
}