/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garajetest;

/**
 *
 * @author jmrivera
 */
public class Coche extends Vehiculo{
    
  private int numPlazas;

  public Coche(int numPlazas, String matricula, float potencia) {
      super(potencia, matricula);
      this.numPlazas = numPlazas;
  }

  public int getNumPlazas() {
      return numPlazas;
  }

    @Override
    public void trucarVehiculo() {
        super.setPotencia(super.getPotencia()*2);
    }


}
