/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package garajetest;

import java.util.Scanner;

/**
 *
 * @author jmrivera
 */
public class Garaje {
    
  private Vehiculo[] vehiculos;
  private int numPlazas;
  private int plazaLibre;

  public Garaje(int numPlazas) {
    this.numPlazas = numPlazas;
    this.vehiculos = new Vehiculo[numPlazas];
    this.plazaLibre = 0;
  }

  public int getPlazaLibre() {
     return plazaLibre;
  }
  
  public boolean hayPlazas(){
    return plazaLibre < numPlazas;
  }
  
  public boolean añadirVehiculo(){
    Scanner teclado = new Scanner(System.in);
    boolean estado = false;
    char tipoVehiculo;
    float potencia;
    int plazas;
    String matricula;

    if(hayPlazas()){
        System.out.print("Tipo de vehículo (coche/moto): ");
        tipoVehiculo = teclado.nextLine().charAt(0);
        if(tipoVehiculo == 'm' || tipoVehiculo == 'c'){
          System.out.print("Matrícula: ");
          matricula = teclado.nextLine();
          System.out.print("Potencia: ");
          potencia = Float.parseFloat(teclado.nextLine());
          switch(tipoVehiculo){
              case 'c':
                  System.out.print("Número de plazas: ");
                  plazas = Integer.parseInt(teclado.nextLine());
                  vehiculos[plazaLibre] = new Coche(plazas, matricula, potencia);
                  plazaLibre++;
                  estado = true;
                  break;
              case 'm':
                  vehiculos[plazaLibre] = new Moto(potencia, matricula);
                  plazaLibre++;
                  estado = true;
                  break;
              default:
                  // no hacer nada
          }
        }
    }
    return estado;
  }

  public Vehiculo devuelveVehiculo(int posicion){
      if(posicion < plazaLibre)
          return vehiculos[posicion];
      else
          return null;
  }

  public double cuotaMes(int posicion){
    Vehiculo miVehiculo = devuelveVehiculo(posicion);
    if (posicion >= 0 && posicion < plazaLibre){
        if(miVehiculo instanceof Coche){
            return miVehiculo.getPotencia() * ((Coche) miVehiculo).getNumPlazas() ;
        }else if(miVehiculo instanceof Moto) {
            return miVehiculo.getPotencia()*2;
        }
    }
    return 0.0;
  }
}
