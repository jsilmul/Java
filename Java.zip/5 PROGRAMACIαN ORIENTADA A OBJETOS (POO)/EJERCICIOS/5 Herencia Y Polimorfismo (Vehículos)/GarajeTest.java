/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package garajetest;

/**
 *
 * @author jmrivera
 */
public class GarajeTest {

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    // TODO code application logic here
    Garaje miGaraje = new Garaje(3);
    Vehiculo unVehiculo;
    // Rellenar garaje
    while(miGaraje.hayPlazas()){
      if (miGaraje.añadirVehiculo()){
        System.out.println("Aparcado.\n");
      }else{
        System.out.println("Error.\n");
      }
    }
    System.out.println("Garaje lleno.");
    // Consultar garaje
    for(int i = 0; i < miGaraje.getPlazaLibre(); i++ ){
      unVehiculo = miGaraje.devuelveVehiculo(i);
      if(unVehiculo instanceof Coche){
        System.out.print("El coche ");
      }else{
        System.out.print("La moto ");
      }
      System.out.println(unVehiculo.getMatricula()+" tiene una cuota de "+miGaraje.cuotaMes(i));
    }
  }

}
