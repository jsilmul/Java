/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionarempresa;

/**
 *
 * @author JMRivera
 */
public class Empresa {
  
  private String nombreEmpresa;
  private String cif;
  private int numeroEmpleados;
  private Cuenta cuentaEmpresa;
  private Empleado[] empleados;

  public Empresa(String nombreEmpresa, String cif, double saldo) {
    this.nombreEmpresa = nombreEmpresa;
    this.cif = cif;
    this.numeroEmpleados = 0;
    empleados = new Empleado[20];
    cuentaEmpresa = new Cuenta(nombreEmpresa, cif, 10, saldo);
  }

  public String getNombreEmpresa() {
    return nombreEmpresa;
  }

  public void setNombreEmpresa(String nombreEmpresa) {
    if (nombreEmpresa != "")
      this.nombreEmpresa = nombreEmpresa;
  }

  public String getCif() {
    return cif;
  }

  public void setCif(String cif) {
    if (cif != "")
     this.cif = cif;
  }

  public int getNumeroEmpleados() {
    return numeroEmpleados;
  }

  public void setNumeroEmpleados(int numeroEmpleados) {
    this.numeroEmpleados = numeroEmpleados;
  }

  public Cuenta getCuentaEmpresa() {
    return cuentaEmpresa;
  }

  public void setCuentaEmpresa(Cuenta cuentaEmpresa) {
    this.cuentaEmpresa = cuentaEmpresa;
  }

  public Empleado[] getEmpleados() {
    return empleados;
  }

  public void setEmpleados(Empleado[] empleados) {
    this.empleados = empleados;
  }
 
  public boolean contratar(Empleado e){
    boolean estado = false;
    
    if(numeroEmpleados < empleados.length && e != null){
      empleados[numeroEmpleados] = e;
      numeroEmpleados++;
      estado = true;
    }
    return estado;
  }
  
  public Empleado devolverEmpleado(int posicion){
    Empleado e = null;
    
    if (posicion >= 0 && posicion < numeroEmpleados){
      e = empleados[posicion];
    }
    return e;
  }
  
  public boolean pagarNomina(int posicion){
    Empleado e = devolverEmpleado(posicion);
    boolean estado = false;
    if (e != null){
      cuentaEmpresa.transferencia(e.getCuentaEmpleado(), e.extras()+e.getSalario());
      estado = true;
    }
    return estado;
  }
  
  public void listarEmpleados(){
    System.out.println("Listado de empleados:\n");
    for (int i = 0; i < numeroEmpleados ;i++ ){
      empleados[i].datosEmpleados();
      System.out.println("");
    }
  }

  public void datosEmpresa() {
    System.out.println("Empresa: "+nombreEmpresa);
    System.out.println("CIF: "+cif);
    System.out.println("Saldo: "+cuentaEmpresa.getSaldo());
  }
 
  
}
