/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestionarempresa;

import java.util.Scanner;

/**
 *
 * @author JMRivera
 */
public class GestionarEmpresa {

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    Scanner teclado = new Scanner(System.in);
    Empresa miEmpresa = new Empresa("Paquetes S.A.", "A41234567", 1000000);
    int opcion, posicion;
    char modificar;
    Empleado miEmpleado;
    double importe;
    
    do{
      opcion = menu();
      switch(opcion){
        case 1:
          System.out.println("\nDatos de la empresa:");
          miEmpresa.datosEmpresa();
          System.out.println("¿Quiere modificar los datos (s/n)?:");
          try{
            modificar = teclado.nextLine().charAt(0);
          }catch(Exception e){
            modificar = 'n';
          }  
          if (modificar == 's'){
            System.out.println("Nuevo nombre:");
            miEmpresa.setNombreEmpresa(teclado.nextLine());
            System.out.println("Nuevo CIF:");
            miEmpresa.setCif(teclado.nextLine());
          }
          break;
        case 2:
          miEmpleado = pedirDatosEmpleados();
          if (miEmpresa.contratar(miEmpleado)){
            System.out.println("Contratado.");
          }else{
            System.out.println("Error en la contratación.");
          }
          break;
        case 3:
          System.out.println("Número del empleado:");
          try{
            posicion = Integer.parseInt(teclado.nextLine());
          }catch(NumberFormatException e){
            posicion = -1;
          }   
          miEmpleado = miEmpresa.devolverEmpleado(posicion);
          if (miEmpleado != null){
            miEmpleado.datosEmpleados();
          }
          break;

        case 4:
          miEmpresa.listarEmpleados();
          break;
        case 5:
          System.out.println("Pagando nóminas y extras:");
          for(int i = 0; i < miEmpresa.getNumeroEmpleados(); i++){
            if(!miEmpresa.pagarNomina(i)){
              System.out.println("Error pagando nómina empleado: "+miEmpresa.devolverEmpleado(i).getDni());
            }else{
              System.out.println("Pagada la nómina del empleado: "+miEmpresa.devolverEmpleado(i).getDni());
            }
          }
          break;
        case 6:
          System.out.println("Importe a ingresar:");
          try{
            importe = Double.parseDouble(teclado.nextLine());
          }catch(NumberFormatException e){
            importe = 0.0;
          }
          if (!miEmpresa.getCuentaEmpresa().ingreso(importe)){
            System.out.println("Error ingresando: "+importe);
          }else{
            System.out.println("Importe ingresado.");
          }
          break;
      }
      esperar();
    }while(opcion != 0);
  }
  
  public static int menu(){
    Scanner teclado = new Scanner(System.in);
    int op;
    System.out.println("Menu");
    System.out.println("");
    System.out.println("1.- Ver/modificar los datos de la empresa.");
    System.out.println("2.- Contratar a un empleado.");
    System.out.println("3.- Ver los datos de un empleado.");
    System.out.println("4.- Ver los datos de todos los empleado.");
    System.out.println("5.- Pagar todas las nóminas.");
    System.out.println("6.- Ingresar en la cuenta de la empresa.");
    System.out.println("0.- Salir.");
    System.out.println("\nElija opción:");
    try{
      op = Integer.parseInt(teclado.nextLine());
    }catch(NumberFormatException e ){
      op = 100;
    }
    return op;
  }
  /**
   * 
   * @return 
   */
  public static Empleado pedirDatosEmpleados(){
    Empleado e = null;
    Scanner teclado = new Scanner(System.in);
    char tipoEmpleado;
    String nombre, dni;
    double salario, comision;
    int horasExtras, proyectos; 
    
    System.out.println("\nTipo del nuevo empleado (programador/gerente):");
    try{
      tipoEmpleado = teclado.nextLine().charAt(0);
    }catch(Exception error){
      tipoEmpleado = 'x';
    }
    if (tipoEmpleado == 'p' || tipoEmpleado == 'g'){
      System.out.println("Nombre:");
      nombre = teclado.nextLine();
      System.out.println("DNI:");
      dni = teclado.nextLine();
      System.out.println("Salario:");
      salario = Double.parseDouble(teclado.nextLine());
      switch(tipoEmpleado){
        case 'p':
          System.out.println("Horas extras:");
          horasExtras = Integer.parseInt(teclado.nextLine());
          e = new Programador(horasExtras, nombre, dni, salario);
          break;
        case 'g':
          System.out.println("Comisión:");
          comision = Double.parseDouble(teclado.nextLine());
          System.out.println("Número de proyectos:");
          proyectos = Integer.parseInt(teclado.nextLine());
          e = new Gerente(comision, proyectos, nombre, dni, salario);
          break;
      }
    }
    return e;
  }
    /**
     * Método que espera pulsar intro para continuar
     */
     public static void esperar(){
        Scanner teclado = new Scanner(System.in);
        System.out.println("Pulse intro para continuar...");
        teclado.nextLine();
    }   
}
