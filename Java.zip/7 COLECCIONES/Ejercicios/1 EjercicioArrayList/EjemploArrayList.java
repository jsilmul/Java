package ejercicioarraylist;

import java.util.ArrayList;
import java.util.Collections;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author Alumno_T
 */

public class EjemploArrayList {

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    // TODO code application logic here
    ArrayList<Alumno> lista = new ArrayList<Alumno>();
    Alumno al;
    int opcion;
    cargarAlumnos(lista);
    do {
      opcion = menu();
      switch (opcion) {
        case 1:
          verArray(lista);
          verArrayNumerado(lista);
          break;
        case 2:
          Collections.sort(lista);
          break;
        case 3:
          al = pedirDatos();
          lista.add(al);
          break;
        case 4:
          al = new Alumno(Entrada.leerCadena("Nombre: "),"",0);
          int i = lista.indexOf(al);
          if (i>0){
            lista.get(i).ver();
            lista.remove(i);
          }
          break;
        default:
      }
    } while (opcion != 0);

  }

  
  
    public static int menu() {
    int op;
    System.out.println("Menu");
    System.out.println("");
    System.out.println("1.- Ver listado alumnos.");
    System.out.println("2.- Ordenar listado alfabéticamente.");
    System.out.println("3.- Dar de alta un alumno.");
    System.out.println("4.- Dar de baja un alumno.");
    System.out.println("0.- Salir.");
    op = Entrada.leerEntero("\nElija opción:");

    return op;
  }

     public static void leerAlumnoDeFichero(ArrayList<Alumno> lista) {
       FileInputStream fichero = null;
       ObjectInputStream entrada = null;
       Alumno al = null;
       try {
           fichero = new FileInputStream("Alumno.dat");
           entrada = new ObjectInputStream(fichero);
           al = (Alumno) entrada.readObject();
           
           while (al != null){
               lista.add(al);
               al = (Alumno) entrada.readObject();
           }
                   
       } catch (FileNotFoundException e) {
           System.out.println(e.getMessage());
       } catch (IOException | ClassNotFoundException e) {
            //
       } finally {
            try {
               if (fichero != null) {
                   fichero.close();
               }
               if (entrada != null) {
                   entrada.close();
               }
            } catch (IOException e) {
            }
       }
       
   }
     
     
     
     
     
  public static void guardarAlumnosEnFichero(ArrayList<Alumno> lista) {
        FileOutputStream fichero = null;
        ObjectOutputStream salida = null;
        
        
      try {
           fichero = new FileOutputStream("Alumno.dat");
           salida = new ObjectOutputStream(fichero);
           salida.writeObject(lista);
           
           //for-each
           for (Alumno al : lista) {  
           salida.writeObject(al);    
           }
           
      } catch (IOException e) {
           System.out.println(e.getMessage());
      } finally {
            try {
               if (fichero != null) {
                   fichero.close();
               }
               if (salida != null) {
                   salida.close();
               }    
           } catch (IOException e) {
           }
      }
  }
     
    
  
  
      
  public static void verArray(ArrayList<Alumno> lista) {
    System.out.println("\nAlumno \t\t\t Nota");
    for (Alumno al : lista) {
      al.ver();
    }
  }

  public static void verArrayNumerado(ArrayList<Alumno> lista) {
    System.out.println("\nAlumno \t\t\t Nota");
    for (int i = 0; i <lista.size(); i++) {
      System.out.print(i+"\t");
      lista.get(i).ver();
    }
  }


  public static void cargarAlumnos(ArrayList<Alumno> lista) {
    Alumno al;

    al = new Alumno("Daniel", "Garcia Gonzalez", 5);
    lista.add(al);
    al = new Alumno("Marcos", "Varela Muñoz", 9);
    lista.add(al);
    al = new Alumno("Lucia", "Casado Caballero", 9);
    lista.add(al);
    al = new Alumno("Manuel", "Del Cuvillo Porrua", 7);
    lista.add(al);
    al = new Alumno("Angela", "Borges Cantarino", 8);
    lista.add(al);
    al = new Alumno("Alejandro", "Ruiz Martin", 6);
    lista.add(al);
    al = new Alumno("Jeronimo", "Silva Mulero", 10);
    lista.add(al);
    al = new Alumno("Manuel Alfonso", "Asuero Guerrero", 7);
    lista.add(al);
  }

  private static Alumno pedirDatos() {
    Alumno al = new Alumno();
    al.setNombre(Entrada.leerCadena("Nombre: "));
    al.setApellidos(Entrada.leerCadena("Apellidos: "));
    al.setNota(Entrada.leerDouble("Nota: "));
    return al;
  }

  
}
