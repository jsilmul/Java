/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ordenararraylist;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author JMRivera
 */
public class OrdenarArrayList {

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    // TODO code application logic here
    ArrayList<Persona> agenda = leerFichero();
    Persona p = null;
    int tlf, indice;
    int op;
    do {
      op = menu();
      switch (op) {
        case 1:
          ver(agenda);
          break;
        case 2:
          p = new Persona();
          agenda.add(p);
          break;
        case 3:
          tlf = Entrada.leerEntero("Telefono a borrar:");
          p = new Persona("","",tlf,"");
          agenda.remove(p);
          break;
        case 4:
          tlf = Entrada.leerEntero("Telefono a buscar:");
          p = new Persona("","",tlf,"");
          indice = agenda.indexOf(p);
          p = agenda.get(indice);
          System.out.println(p.toString());
          break;
        case 5:
          int orden = Entrada.leerEntero("\n 1.- Por telefonos.\n 2.- Por apellidos.\n 3.- Por email.\n ¿Que orden?");
          switch (orden) {
            case 1:
              Collections.sort(agenda, new OrdenTelefono());
              break;
            case 2:
              Collections.sort(agenda);
              break;
            case 3:
              Collections.sort(agenda, new OrdenEmail());
              break;
            default:
          }
          ver(agenda);
          break;
        default:
      }
    } while (op != 0);
    guardarFichero(agenda);
  }

  public static int menu() {
    int opcion;
    System.out.println("\n\tMENU");
    System.out.println("1.- Ver agenda");
    System.out.println("2.- Dar de alta");
    System.out.println("3.- Dar de baja");
    System.out.println("4.- Buscar persona");
    System.out.println("5.- Ordenar agenda");
    System.out.println("0.- Salir");
    opcion = Entrada.leerEntero("\nIntroduzca opcion:");
    return opcion;
  }

  public static void ver(ArrayList<Persona> agenda) {
    System.out.println("Telefono \tNombre  \t\temail");
    System.out.println("-------- \t------  \t\t-----");
    for (Persona p : agenda) {
      System.out.println(p.toString());
    }
  }

  public static ArrayList<Persona> leerFichero() {
    ArrayList<Persona> agenda = new ArrayList<Persona>();
    FileInputStream fichero = null;
    ObjectInputStream entrada = null;
    Persona p = null;
    try {
      fichero = new FileInputStream("Agenda.dat");
      entrada = new ObjectInputStream(fichero);
      p = (Persona) entrada.readObject();
      while (p != null) {
        agenda.add(p);
        p = (Persona) entrada.readObject();
      }
    } catch (FileNotFoundException e) {
      System.out.println(e.getMessage());
    } catch (IOException | ClassNotFoundException e) {
      //
    } finally {
      try {
        if (fichero != null) {
          fichero.close();
        }
        if (entrada != null) {
          entrada.close();
        }
      } catch (IOException e) {
      }
    }
    return agenda;
  }

  public static void guardarFichero(ArrayList<Persona> agenda) {
    FileOutputStream fichero = null;
    ObjectOutputStream salida = null;
    try {
      fichero = new FileOutputStream("Agenda.dat");
      salida = new ObjectOutputStream(fichero);
      for (Persona p : agenda) {
        salida.writeObject(p);
      }
    } catch (Exception e) {
      System.out.println(e.getMessage());
    } finally {
      try {
        fichero.close();
        salida.close();
      } catch (Exception e) {
      }
    }
  }
}
