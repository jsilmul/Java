/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package actividadhashmap;

import java.util.HashMap;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author Jero
 */
public class EjemploHashMap {

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    // TODO code application logic here
    HashMap<Integer,Persona> agenda = new HashMap<Integer,Persona>();
    Persona p = null;
    
    Persona misPersonas = leerPersonaFichero();
    int numeroPersonas = 0;
    
    if (misPersonas == null){
        misPersonas = new Persona();
        numeroPersonas = 0;
    }else{
        numeroPersonas = misPersonas.hashCode();
    }
    
    int tlf;
    int op;
    do{
      op = menu();
      switch (op) {
        case 1:
          ver(agenda);
          break;
        case 2:
          p = new Persona();
          agenda.put(p.hashCode(), p);
          break;
        case 3:
          tlf = Entrada.leerEntero("Telefono a borrar:");
          agenda.remove((Integer)tlf);
          break;
        case 4:
          tlf = Entrada.leerEntero("Telefono a buscar:");
          p = agenda.get((Integer)tlf);
          System.out.println(p.toString());
          break;
        case 5:
          guardarPersonaEnFichero(misPersonas);
            break;
        case 6:
          misPersonas = leerPersonaFichero();
          numeroPersonas = misPersonas.hashCode();
            break;
        default:

      }
    }while(op != 0);
  }
  
  public static int menu(){
    int opcion;
    System.out.println("\t MENU\t");
    System.out.println("1.- Ver agenda");
    System.out.println("2.- Dar de alta");
    System.out.println("3.- Dar de baja");
    System.out.println("4.- Buscar persona");
    System.out.println("5.- Guardar objetos de tipo persona en un fichero");
    System.out.println("6.- Leer objetos de tipo persona en un fichero");
    opcion = Entrada.leerEntero("Introduzca opcion:");
    return opcion;
  }
  
  
    public static void guardarPersonaEnFichero(Persona persona){
    FileOutputStream fichero = null;
    ObjectOutputStream salida = null;
    try{
        fichero = new FileOutputStream("Persona.dat");
        salida = new ObjectOutputStream(fichero);
        salida.writeObject(persona);
    }catch(Exception e){
        System.out.println(e.getMessage());
    }finally{
      try{
        fichero.close();
        salida.close();
      }catch(IOException e){}
    }
  }  
    
    public static Persona leerPersonaFichero(){
    FileInputStream fichero = null;
    ObjectInputStream entrada = null;
    Persona persona = null;
    try{
        fichero = new FileInputStream("Persona.dat");
        entrada = new ObjectInputStream(fichero);
        persona = (Persona) entrada.readObject();
    }catch(FileNotFoundException  e){
        System.out.println(e.getMessage());
    }catch(IOException | ClassNotFoundException   e){
      //
    }
    finally{
        try{
            if (fichero != null)
                fichero.close();
            if (entrada != null)
                entrada.close();
        }catch(IOException  e){
        }
    }
    return persona;
  } 
    
    
  public static void ver(HashMap<Integer,Persona> agenda ) {
    System.out.println("Nombre \t telefono \t email");
    for(Persona p: agenda.values()){
      System.out.println(p.toString());
    }

  }
}