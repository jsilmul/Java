***********************************************************************************
Crea las funciones de búsqueda descritas en los apuntes y el programa que las utilize:
//Búsqueda //Búsqueda ordenada //Búsqueda binaria
//Búsqueda simple //Búsqueda ordenada //Búsqueda binaria
//Método de selección //Método de la burbuja
//Inserción en orden y desplazamiento //Borrado con desplazamiento


//main do switch default if else while
//menu return op
//busqueda simple (Scanner t)



 import java.util.Scanner;
/**
 *
 * @author Alumno_T
 */
 
public class BusqOrdenac1 {
    /**
    * Crea las funciones de búsqueda descritas en los apuntes y el programa que las utilize:
    * //Búsqueda simple //Búsqueda ordenada //Búsqueda binaria
    * //Método de selección //Método de la burbuja
    * //Inserción en orden y desplazamiento //Borrado con desplazamiento
    */
    
    public static void main(String[] args) {
    // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        int op;
        
        do{

            op = menu(teclado);
            
            switch (op){
                case 1:
                busquedasimple(teclado);
                break;
                case 2:
                busquedaordenada(teclado);
                break;
                case 3:
                busquedabinaria(teclado);
                break;
                case 4:
                metodoseleccion(teclado);
                break;
                case 5:
                ordenacionburbuja(teclado);
                break;
                case 7:
                insercionydesplazamiento(teclado);
                break;
                case 8:
                borradocondesplazamiento(teclado);
                break;
                case 0:
                ;
                default:
    }   
      
            if (op != 0){
                System.out.println("\nPulsa enter para continuar...");
                teclado.nextLine();
            }else{
                System.out.println("\nFin del programa");   
                
            }
            
        }while (op != 0);
        
    }

    //Menu del programa
    public static int menu (Scanner t){
    System.out.println("Menu de funciones de busqueda, ordenacion, insercion y borrado de vectores");
    System.out.println("------------");
    System.out.println("");
    System.out.println("1.- Busqueda Simple");
    System.out.println("2.- Busqueda Ordenada");
    System.out.println("3.- Busqueda Binaria");
    System.out.println("4.- Metodo de Seleccion");
    System.out.println("5.- Metodo de la Burubuja");
    System.out.println("6.- Insercion y Desplazamiento");
    System.out.println("7.- Borrado con Desplazamiento");
    System.out.println("0.- ");
    System.out.println("");
    System.out.println("Introduce opcion");
    int op = Integer.parseInt(t.nextLine());
    System.out.println();
    return op;         
    }
    
    
    
    
    //Función que rellena el vector aleatoriamente
    public static void rellenarvector(int[] v){
          
        for(int i=0; i<v.length; i++){
        v[i] = (int)(Math.random()*11);
        }
    }
    
    
    // Funcion de busqueda simple
    public static int busquedasimple(int v[], int tam) {
    
    for (int i = 0; i < v.length; i++) {
        if (v[i] == tam)
            return i;
    }
    return -1;
    }
    
    
    // Funcion de busqueda ordenada
    public static int busquedaordenada(int v[], int tam) {
    int i =0;
    int pos = -1;
    while(i< tam && pos == -1 && v[i] <= pos){
        if (v[i] == pos){
            pos = i;
        }
        i = i++;
    }
    
    
    // Funcion de busqueda binaria
    public static int busquedabinaria(int v[], int tam) {
        int centro, primero, ultimo, valorCentro;
        primero=0;
        ultimo = v.length -1;
        while(primero <= ultimo){
            centro = (primero + ultimo) / 2;
            valorCentro=v[centro];
            System.out.println("Comparo" + tam + "con " + v[centro]);
            if(tam ==valorCentro){
                return centro;
            }else if (tam < valorCentro){
                ultimo =centro - 1; //Desplazamiento hacia la izquierda
            }else{
                primero = centro + 1; //Desplazamiento hacia la derecha
            }
        }
        return -1;
    }

    
    
    
    
    
    // Funcion de ordenación por selección
    public static void metodoseleccion(int []v) {
        int i, j, menor, pos, tam;
        for (i = 0; i < v.length - 1; i++) {       // tomamos como menor el primero
             menor = v[i];                         // de los elementos que quedan por ordenar                    
             pos = i;                              // y guardamos su posición
             for (j = i + 1; j < v.length; j++){   // buscamos en el resto
                    if (v[j] < menor) {            // del array algún elemento
                        menor = v[j];              // menor que el actual
                        pos = j;
                    }
             }
             if (pos != i){                        // si hay alguno menor se intercambia                         
                  tam = v[i];
                  v[i] = v[pos];
                  v[pos] = tam;
             }
        }
    }
    
    
    
    
    // Función de ordencion por el método de la burbuja
    public static void ordenacionburbuja(int[] v) {
        
        int i, j, aux;
        for (i = 0; i < v.length - 1; i++) {
            for (j = 0; j < v.length - i - 1; j++) {
                if (v[j + 1] < v[j]) {
                    aux = v[j + 1];
                    v[j + 1] = v[j];
                    v[j] = aux;
                }
            }
        }
    }
    
    
    
    // Funcion de inserción en orden y desplazamiento
    public static void insercionydesplazamiento(int [] v){
        
        int i, j, aux;
        for (i = 1; i < v.length; i++){
        /* indice j es para explorar la sublista a[i-1]..a[0] buscando la
        posicion correcta del elemento destino*/
        j = i;
        aux = v[i];
        // se localiza el punto de inserción explorando hacia abajo
           while (j > 0 && aux < v[j-1]){
           // desplazar elementos hacia arriba para hacer espacio
           v[j] = v[j-1];
           j--;
           }
        v[j] = aux;
        }
    }
    
    
    // Funcion de borrado con desplazamiento
    public static void borradocondesplazamiento(int [] v){
    

     
    }
    
    
    
}