[VECTORES]



vector 1---------------------------------------------------------------------------------

JUSTO DESPUÉS DE author


import java.util.Scanner;

public class Vector1 {
    /**
     * @param args the command line arguments
     */ 
    private static int[] nota;
    final static int POS = 5;
    
    public static void main(String[] args) {
        // TODO code application logic here
    /**
    * Diseñar un algoritmo que pida 5 notas que se almacenaran en un array y calcule las notas máxima, mínima y 
    * media. Para ello diseña las funciones: Rellenar(vector, tam) que no devuelve nada y las funciones
    * Maximo(vector, tam), Minimo(vector, tam) y Media(vector, tam) que devolverán nota máxima, mínima y la 
    * media respectivamente.
    */     
    Scanner teclado = new Scanner(System.in);    
    int v=5;
    int [] notas;
    float media = 0;
    float maximo;
    float minimo;
    notas = new int [v];
    
    for(int i = 0; i < notas.length; i++) {
        System.out.println("Introduzca la nota del alumno " + (i + 1) + ": ");
        int dato = Integer.parseInt(teclado.nextLine());
        notas[i] =  dato;
    }
    
    for (int i = 0; i < POS; i++) {
        media += notas[i];
    }
    
    media = media / notas.length;
    System.out.println("La nota media es: " + media);

    maximo = notas[0];
    for (int i = 0; i > notas.length; i++){
         if (notas[i] > maximo){
            maximo = notas [i];
         }
    }  
    System.out.println("La nota maxima es: " + maximo);
    
    
    
    minimo = notas[0];
    for (int i = 0; i < notas.length; i++){
         if (notas[i] < maximo){
            minimo = notas [i];
         }
    }  
    System.out.println("La nota minima es: " + minimo);
    
   }        
}



vector 2---------------------------------------------------------------------------------

JUSTO DESPUÉS DE author


public class Vector2 {

    /**
     * @param args the command line arguments
     */
    private static int [] pares;
            
    public static void main(String[] args) {
        // TODO code application logic here
        
    /**
    * Diseñar un algoritmo que cree un vector de 20 elementos llamado pares, lo rellene con los 20 primeros
    * números pares y muestre su contenido: crear las funciones Rellenar y Mostrar, correspondientes.
    */
  
    int v=20;
    pares = new int [v];
     
    for(int i = 0; i <pares.length; i++){
         pares[i] = i*2;
    }
      
    for(int i = 0; i <pares.length; i++){
        System.out.print(pares [i] + " ");
    }
        
                   
  }  
}




vector 3---------------------------------------------------------------------------------

JUSTO DESPUÉS DE author


import java.util.Scanner;

public class Vector3 {

    /**
     * @param args the command line arguments
     */
	 
	private static int[] tiradas;
	 
    public static void main(String[] args) {
        // TODO code application logic here
        
        /**
        * Diseñar un algoritmo que cree un vector de 100 elementos, almacene en él las tiradas de un dado 
        * (recuerda la función azar ( n ) ). Por último deberá mostrar cuantas veces ha aparecido cada punto 
        * del dado. Diseñar la función Tiradas que rellene el vector y la función ContarPunto(vector, punto, tam) 
        * que devolverá cuantas veces aparece en el vector el valor punto.
        */
		
	int v=100;
    tiradas = new int [v];
    int contadores[] = new int [6];
    int cont1=0;
    int cont2=0;
    int cont3=0;
    int cont4=0;
    int cont5=0;
    int cont6=0;
        
        
        for(int i = 0; i < tiradas.length; i++){
            tiradas[i] = (int)(Math.random() * 6+1);
        }
        
        for(int i = 0; i < tiradas.length; i++){
            
            switch (tiradas[i]){
            
                    case 1:
                    cont1++;
                    break;
                    case 2:
                    cont2++;
                    break;
                    case 3:
                    cont3++;
                    break;
                    case 4:
                    cont4++;
                    break;
                    case 5:
                    cont5++;
                    break;
                    case 6:
                    cont6++;
                    break;    
            }
        }
         
        System.out.println("El 1 ha salido " + cont1);
        System.out.println("El 2 ha salido " + cont2);
        System.out.println("El 3 ha salido " + cont3);
        System.out.println("El 4 ha salido " + cont4);
        System.out.println("El 5 ha salido " + cont5);
        System.out.println("El 6 ha salido " + cont6);
    }
 } 



vector 4---------------------------------------------------------------------------------

JUSTO DESPUÉS DE author



public class Vector4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /**
         * Diseñar un algoritmo que cree un vector de 100 elementos, almacene en él 100 notas generadas al azar 
         * (recuerda la función azar ( n ) ). Por último deberá mostrar cuantos aprobados y cuantos suspensos hay.
         * Igual que el anterior con las funciones CuentaAprobados y CuentaSuspensos
         */
        
        int [] notas = new int [100];
        rellenarvector(notas);
		
		
        System.out.println("Escribe un vector de 100 notas");
        System.out.println(" El numero de aprobados es: " + cuentaaprobados(notas));
        System.out.println(" El numero de suspensos es: " + cuentasuspensos(notas));
         
         }
    
   
     public static void rellenarvector(int[] v){
         
          for(int i=0; i<v.length; i++){
          v[i] = (int)(Math.random()*11);
        }
    }

     
     public static int cuentaaprobados (int[] v){
         int cont = 0;
         
         for(int i=0; i<v.length; i++){
             if(v[i]>= 5){
                 cont++;
       }
     }

     return cont;
     
}

     public static int cuentasuspensos (int[] v){
         int cont  = 0;
         for(int i = 0; i<v.length; i++){
             if(v[i]<5){
                 cont++;
             }
       }
         return cont;
     }

}


vector 5---------------------------------------------------------------------------------

JUSTO DESPUÉS DE author


import java.util.Scanner;

public class Vector5 {

    /**
     * @param args the command line arguments
     */
	 
	private static int[] notas;
	  
	  
    public static void main(String[] args) {
        // TODO code application logic here
    
        /**
         * Diseñar un algoritmo como el anterior que muestre cuantos suspensos, suficientes, bien, notables 
         * y sobresalientes hay. En este caso crearemos la función Rellenar del ejercicio anterior y una función
         * MostrarNotas que mostrará cuantos suspensos, suficientes, bien, notables y sobresalientes hay.
         */

int v=100;
    notas = new int [v];
    int contsusp=0;
    int contsufi=0;
    int contbien=0;
    int contnotab=0;
    int contsobre=0;
        
        
        for(int i = 0; i < notas.length; i++){
            notas[i] = (int)(Math.random() * 11);
        }
        
        for(int i = 0; i < notas.length; i++){
            
            switch (notas[i]){
            
                    case 1:
                    contsufi++;
                    break;
                    case 2:
                    contbien++;
                    break;
                    case 3:
                    contnotab++;
                    break;
                    case 4:
                    contsobre++;
                    break;
          
                    default:
                        contsusp++;
                        break;
            }
        }
         
        System.out.println(contsusp+ " suspensos");
        System.out.println(contsufi+ " suficientes");
        System.out.println(contbien+ " bien");
        System.out.println(contnotab+ " notables");
        System.out.println(contsobre+ " sobreasalientes");
    }
 } 





vector 6---------------------------------------------------------------------------------

JUSTO DESPUÉS DE author



public class Vector6 {

    /**
     * @param args the command line arguments
     */
	 
	private static int[] impares;

	
    public static void main(String[] args) {
        // TODO code application logic here
    
    /**
     * Diseñar un algoritmo que cree un vector de 10 elementos, lo rellene con los 10 primeros números 
     * impares y muestre su contenido en orden inverso. Diseñar la correspondiente funcion RellenarImpar
     * y MostrarAlReves 
     */
    
    int v =10;
    impares = new int[v];
	    
	for(int i = 0; i<impares.length; i++){
        impares[i] = i*2+1;
    }
   
    
    for(int i = impares.length -1; i>=0; i-- ){
        System.out.print(impares[i]+ " ");
    }
 

 
   }
}