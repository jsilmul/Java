[INSTRUCCIONES REPETITIVAS]



instruccion repetitiva 1---------------------------------------------------------------------------------

JUSTO DESPUÉS DE author

import java.util.Scanner;

public class InstruccionRepetitiva1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
    /**
    * Dado un número positivo por el usuario, mostrar todos 
    * los números que hay desde 0 hasta dicho número inclusive.
    */ 
     
     Scanner in = new Scanner(System.in);
     
     System.out.println("Escribe un numero:");
     
     int num = in.nextInt();
    
     
     for (int i = 0; i <= num; i++) {
         System.out.println(i);
     }   
    
    }  
}






instruccion repetitiva 2---------------------------------------------------------------------------------

JUSTO DESPUÉS DE author

import java.util.Scanner;


public class InstruccionRepetitiva2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
     /**
     * Dado dos números positivos (el primero más pequeño que el segundo), mostrar 
     * todos los números que hay desde el primero hasta el segundo (ambos inclusive).
     */ 
    
    Scanner in = new Scanner(System.in);
    
    System.out.println("Escribe un numero:");
    
    int num1 = in.nextInt();
    
    System.out.println("Escribe un numero mayor que el anterior:");
    
    int num2 = in.nextInt();
    
     for (int i = num1; i <= num2; i++) {
         System.out.println(i);
           }

    }  
}





instruccion repetitiva 3---------------------------------------------------------------------------------

JUSTO DESPUÉS DE author

import java.util.Scanner;


public class InstruccionRepetitiva3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
     /**
     * Dados dos números positivos (el primero más pequeño que el segundo), mostrar 
     * la suma de todos los números desde el primero hasta el segundo (ambos inclusive).
     */
     
     Scanner in = new Scanner(System.in);
     
     int suma = 0;
     
     System.out.println("Escribe un numero:");
         
     int num1 = in.nextInt();
    
     System.out.println("Escribe un numero mayor que el anterior:");
    
     int num2 = in.nextInt();
     
     for (int i = num1; i <= num2;  i++) {
         suma += i;
     }
     
     System.out.println("La suma es:"+suma);
    
    }
}






instruccion repetitiva 4---------------------------------------------------------------------------------

JUSTO DESPUÉS DE author

import java.util.Scanner;


public class InstruccionRepetitiva4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
    /**
    * Dado dos números positivos (el primero más pequeño que el segundo), mostrar todos los números, 
    * desde el primero hasta el segundo, que sean divisores de un número concreto 
    * (dado también por el usuario).
    */
    
    Scanner in = new Scanner(System.in);
    
     System.out.println("Escribe un numero:");
         
     int num1 = in.nextInt();
    
     System.out.println("Escribe un numero mayor que el anterior:");
    
     int num2 = in.nextInt();
     
     System.out.println("Escribe un número para mostrar sus divisores:");
    
     int num3 = in.nextInt();
     
     for (int i = num1; i <= num2; i++){
         
         if (num3 % i == 0){
         
           System.out.println(i);
         }
     }
   } 
}






instruccion repetitiva 5---------------------------------------------------------------------------------

JUSTO DESPUÉS DE author

import java.util.Scanner;

public class InstruccionRepetitiva5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        /**
         * Dados dos números positivos (el primero más pequeño que el segundo), mostrar 
         * la suma de todos los números, desde el primero hasta el segundo, que sean divisores 
         * de un número concreto (dado también por el usuario).
         */
        
     Scanner in = new Scanner(System.in);
    
     int suma = 0;
     
     System.out.println("Escribe un numero:");
         
     int num1 = in.nextInt();
    
     System.out.println("Escribe un numero mayor que el anterior:");
    
     int num2 = in.nextInt();
     
     System.out.println("Escribe un número para mostrar sus divisores:");
    
     int num3 = in.nextInt();
     
     
     for (int i = num1; i <= num2; i++){
         
         if (num3 % i == 0){
             
             suma += i;
          }
         
         
       
     }
     System.out.println("La suma es:"+suma);
    }
}





instruccion repetitiva 6---------------------------------------------------------------------------------

JUSTO DESPUÉS DE author

import java.util.Scanner;


public class InstruccionRepetitiva6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
    /**
    *Leer un número e indicar si es positivo o negativo. El proceso se repetirá hasta que se introduzca un 0. 
    */
   
     Scanner in = new Scanner(System.in);
          
     System.out.println("Escribe un numero, 0 para terminar:");
     
     int num1 = in.nextInt();
     
     while (num1 != 0){ 
         
         
         if (num1 > 0){
             System.out.println(+num1+" es positivo");
          }
         
          else if (num1 < 0){
             System.out.println(+num1+" es negativo");      
          }
         
         System.out.println("Escribe otro numero:");
         num1 = in.nextInt();
         
        }  
     }   
 } 
 
 
 
 
 
 
instruccion repetitiva 7---------------------------------------------------------------------------------

JUSTO DESPUÉS DE author

import java.util.Scanner;



public class InstruccionRepetitiva7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
            
    /**
    *Pedir números hasta que se teclee uno negativo. Una vez ocurra esto, el algoritmo debe imprimir 
    *la suma de todos los números introducidos a excepción del número negativo. 
    */
    
     Scanner in = new Scanner(System.in);
    
    int n1, suma;
        suma=0;
	System.out.println("Escribe un número, negativo para terminar: "); 
	
        n1=in.nextInt();
            while (n1>0){
              suma=suma + n1;
              n1=in.nextInt();
            }   
	System.out.println("" +suma ); 
        }       
    }
    



instruccion repetitiva 8---------------------------------------------------------------------------------

JUSTO DESPUÉS DE author

import java.util.Scanner;


public class InstruccionRepetitiva8 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /**
         * Realiza un juego para adivinar un número numSecreto (por ejemplo, entre 0 y 20). 
         * El algoritmo debe ir pidiendo números al usuario indicando si es mayor o menor que numSecreto.
         * El algoritmo acaba cuando el usuario acierta el número (Utilizar la función Math.random()).
         */
        
    Scanner in = new Scanner(System.in);
     

      int n1, numSecreto;
      numSecreto=0;
      System.out.println("Escriba un número entre 0 y 20, para averiguar el número secreto"); 	
      
      n1=in.nextInt();
        numSecreto = (int)(Math.random() * 21); 
            while (n1 != numSecreto){
                if (n1 < numSecreto){
                System.out.println("El número secreto es mayor"); 
                }
                else{
                System.out.println("El número secreto es menor");
                }	
                n1=in.nextInt();
            }   
        System.out.println("Has acertado"); 
    }
}



instruccion repetitiva 9---------------------------------------------------------------------------------

JUSTO DESPUÉS DE author

import java.util.Scanner;

     
public class InstruccionRepetitiva9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /**
         * Pedir 10 números y escribir la suma total.
         */
        
        Scanner in = new Scanner(System.in);
        
        int n1, suma;
        suma=0;
	    System.out.println("Escriba un número, negativo para terminar: "); 
	
        n1=in.nextInt();
            while (n1>0){
              suma=suma + n1;
              n1=in.nextInt();
            }   
	   System.out.println("" +suma );
    }    
}


instruccion repetitiva 10---------------------------------------------------------------------------------

JUSTO DESPUÉS DE author

import java.util.Scanner;


public class InstruccionRepetitiva10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
    /**
    * Pedir un número N, introducir N números y mostrar el mínimo, máximo y la media.
    */ 
     
     Scanner in = new Scanner(System.in);
	 
	 int min=0, max=0, suma=0, num=0;
	 
	 System.out.println("Escribe cuantos numeros va a introducir: ");
	 
	 int n = in.nextInt();
	 
	 for (int i = 0; i<n; i++){
		  num=in.nextInt();
		  
		  if(i==0){
			  min=num;
			  max=num;
		  }
		  if (min>num){
			  min=num;
		  }
		  	  if (max<num){
			  max=num;
		  }
		  suma=suma + num;
		  
   }  
   
   float med=(float) (suma/num);
   System.out.println("El minimo es: "+min);
   System.out.println("El minimo es: "+max);
   System.out.println("La media es: "+med);

    }
}